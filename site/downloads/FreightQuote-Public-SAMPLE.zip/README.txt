FREE SAMPLE ONLY / 免费节选 / 無料見本
Not the full product. All data fictional. No orders or payments. Open the HTML locally and use browser Print / Save PDF. No data input, script, external resource or automatic calculation. MIT.
